# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 18:56:58 2017

@author: Uwe
"""
print('Hello Python')
# Kommentar
a = 123.4
a+=2
print(a+2)

def myFunction(a):
    b = a + a
    return b
    
print(myFunction(2)) # 4
print(myFunction('a')) # 'aa'
