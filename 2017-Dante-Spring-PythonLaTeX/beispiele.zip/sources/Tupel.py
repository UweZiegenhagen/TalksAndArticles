# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:29:31 2017

@author: Uwe
"""
monate=('Jan', 'Feb', 'Mar', 'Apr', 'Mai')
print(monate[1])
print(monate[1:3])