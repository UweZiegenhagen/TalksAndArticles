# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:31:55 2017

@author: Uwe
"""
myString = 'Python'
for c in myString:
    print(c)