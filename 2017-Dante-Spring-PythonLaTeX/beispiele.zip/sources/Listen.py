# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:28:18 2017

@author: Uwe
"""

beatles = ['John', 'Paul', 'Ringo', 'George']
print(len(beatles))
print(beatles[3])
beatles.append('Yoko Ono')
print(beatles.index('John'))