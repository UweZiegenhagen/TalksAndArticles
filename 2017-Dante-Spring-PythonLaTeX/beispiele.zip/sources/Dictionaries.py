# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:30:22 2017

@author: Uwe
"""
lookup={'EUR':'Euro', 'GBP':'Pound', 'USD':'US-Dollar'}
print(lookup['EUR'])