# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:36:34 2017

@author: Uwe
"""
a = input('Erstes Wort')
b = input('Zweites Wort')

print(a, b)
print(a, b, sep='')
print(a, b, sep=':')