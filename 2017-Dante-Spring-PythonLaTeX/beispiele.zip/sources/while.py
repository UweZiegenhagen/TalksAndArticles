# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:32:41 2017

@author: Uwe
"""
n = 4
while n>0:
	print(n)
	n-=1