# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:31:18 2017

@author: Uwe
"""
a = 1

def doThis():
    print('Done')

if a==1:
	doThis()
else:
	pass # pass = "Do nothing"
