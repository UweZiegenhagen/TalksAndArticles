# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 20:27:15 2017

@author: Uwe
"""
meinString = 'Hallo Welt'

print(meinString.upper())
print(meinString.lower())
print(meinString.find('W'))
print(meinString.split(' '))
print(meinString.strip())
print(meinString.replace('Welt', 'World'))