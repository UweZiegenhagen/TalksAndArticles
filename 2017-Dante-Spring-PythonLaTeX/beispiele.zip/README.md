# PythonAndLaTeX

Slides (in German) and example code for my "Doing LaTeX with Python" Tutorial, 2017 in Zeuthen, Germany.

Required to follow the code:

- Python 3.x (Anaconda recommended)
- pandas
- jinja2
- numpy

